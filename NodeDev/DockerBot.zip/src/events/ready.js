module.exports = {
    name: 'ready',
    once: true,
    async execute() {
        console.log('Ready!');
    },
};